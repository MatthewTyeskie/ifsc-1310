// script.js

// Toggle dark mode functionality
const toggle = document.getElementById('toggle-dark');

if (toggle) {
  toggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
  });
}

// Optional: Show confirmation in console
console.log("Dark mode toggle script loaded.");
